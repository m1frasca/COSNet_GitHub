BiocGenerics:::testPackage("COSNet")
